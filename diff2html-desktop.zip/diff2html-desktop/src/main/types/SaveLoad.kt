package types

data class SaveLoad(
	val winDesk: WinDesk,
	val appFields: AppFields
)