import cmd.SysCalls
import javafx.application.Application
import tornadofx.*
import ui.MainUI

object Main {

    @JvmStatic
    fun main(args: Array<String>) {
        val result = SysCalls.runCommand("pwd")
        println("pwd: $result")

        //println(SysCalls.updateBrew())
        //println(SysCalls.installNode())
        //println(SysCalls.installDiff2Html())

        val pathToRepo = "/Users/davrukin/Documents/Programming/RepoCopies/librelinkadc/"
        val outfile = "4521-45301"
        val commit1 = "104e17a59"
        val commit2 = "bd1f98f4d"

        //println(SysCalls.runDiff2Html(pathToRepo, outfile, commit1, commit2))

        Application.launch(DiffApp::class.java)
    }

    private fun doUiStuff() {


        DiffApp().init()

    }

}

class DiffApp : App(MainUI::class)